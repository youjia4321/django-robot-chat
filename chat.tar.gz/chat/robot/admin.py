from django.contrib import admin
from .models import Users, Chat
# Register your models here.

admin.site.register(Users)
admin.site.register(Chat)

