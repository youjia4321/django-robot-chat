from django.shortcuts import render
from django.views.generic.base import View
import requests
import json
from robot.models import Chat
# Create your views here.

def get_response(info):
        # 调用图灵机器人API
        url = 'http://www.tuling123.com/openapi/api?key=80baea7bc2fb422bbba097909952e90c&info=' + info
        res = requests.get(url)
        res.encoding = 'utf-8'
        jd = json.loads(res.text)
        return jd['text']


class Index(View):
    def get(self, request):
        return render(request, 'index.html', {})

    def post(self, request):
        comment = request.POST.get('comment', '')
        recevie = get_response(comment)
        print(comment, recevie)
        chat1 = Chat(chat_comment=comment)
        chat2 = Chat(chat_comment=recevie)
        chat1.save()
        chat2.save()
        return render(request, 'index.html', {'comment': comment, 'recevie': recevie})


def record(request):
    all_chats = Chat.objects.all()
    return render(request, 'record.html', {'all_chats': all_chats})