from django.apps import AppConfig


class RobotConfig(AppConfig):
    name = 'robot'
